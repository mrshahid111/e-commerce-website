compare_item     = [];
wished_item      = [];
const localStorageAllowAccess = window.localStorage

// current_lat     = '';
// current_lng     = '';
current_lat = '12.972442';
current_lng = '77.580643';
var thisURL      = decodeURIComponent(window.location.href);
var uri          = "shop/";
var key_uri      = (thisURL.split(uri)[1] != '' ? thisURL.split(uri)[1] : '' );

// if( == '' || thisURL.split(uri)[1] == 'compare/'){
//     $('.compare-sticky').hide();
// }
$(document).ready(function(){
    $('#year').text(new Date().getFullYear());
    callCartCount();
    callNotificationCount()
    // console.log(key_uri);
    var pathArray   = key_uri;
    // console.log(pathArray);
    if(pathArray == 'compare/' || pathArray == 'cart/' || pathArray == 'checkout1/' || pathArray == 'checkout/'){
        $('.compare-sticky').hide();
    } else if(key_uri != '' && key_uri != null){
        compare_item_details();
    } else {
        $('.compare-sticky').hide();
    }
    
    $(this).text('location');
    
    wish_list_details();
    set_defult_location();
    
    $(document).ready(function() {
        if ($('div').hasClass('available-address')) {
            $.ajax({
                type: "GET",
                url: '/accounts/get_customer_address/?token',
                dataType: "json",
                success: function (result) {
                    // console.log(result);
                    if (result.res_list.length > 0) {
                        var saved_pincode = '';
                        saved_pincode +=`<ul>`;
                        $.each(result.res_list, function (i, value) {

                            var address_html = value.address?.replace('/\r\n',"<br/>");
                            
                            if(value.pin_code != ''){
                                // saved_pincode +=`
                                //                 <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                                //                     <div class="d-flex">
                                //                         <div>
                                //                              <input type="radio" name="pincode_address" id="set_pincode_${value.id}" value="${value.pin_code}" class="checkBox_customer_address" data-pin_code="${value.pin_code}" >
                                //                         </div>
                                //                         <label class="form-check-label" for="set_pincode_${value.id}">
                                //                             <div class="address-details">
                                //                                 <span>
                                //                                 ${address_html} 
                                //                                 <br>
                                //                                 ${value.city != '' ? value.city : ''} 
                                //                                 <br>
                                //                                 ${value.state != '' && value.state != null ? value.state.name : ''}
                                //                                 </span>
                                //                                 <span class="pincode">${value.pin_code}</span>
                                //                             </div>
                                //                         </label>
                                //                     </div>
                                //                 </div>
                                //             `;

                                saved_pincode +=`<li>
                                                <a href="javascript:void(0);" class="set_location_based" data-pincode="${value.pin_code}" data-locality="${value.area}">
                                                    <div class="address-details">
                                                        <span><strong>${value.name} </strong> - ${address_html} ${value.city != '' ? ', ' + value.city : ''} ${value.state != '' && value.state != null ? ', ' + value.state.name : ''}   </span>
                                                        <span class="pincode"> - ${value.pin_code}</span>
                                                    </div>
                                                </a>
                                                </li>`;
                            }
                        })
                        $('.available-address').html(saved_pincode);
                    }
                }
            })
        } 
    });
})

function set_defult_location(){
    $.ajax({
        type: "GET",
        url : '/api/get_location_x/',
        dataType: "json",
        success: function(success) {
            // console.log(success);
            $('.change_location').text(success.name);
            $('.change_location').attr("data-state-id",success.state_id);
            $('ul.t-header-location a').attr("title",success.name);
            
        },
        error: (error) => console.log("error is =>", error),
    });
}


$(document).on('click','#change_location',function(e){
    e.preventDefault();
    set_defult_location();
    $('#location').modal('hide');
    // $(this).text('location');
    // $.ajax({
    //     type: "GET",
    //     url : '/api/get_location_x/',
    //     dataType: "json",
    //     success: function(success) {
    //         // console.log(success.name);
    //         $('.change_location').text(success.name);
    //         $('.change_location').attr("data-state-id",success.state_id);
    //         $('#location').modal('hide');
    //     },
    //     error: (error) => console.log("error is =>", error),
    // });
})

function callCartCount() {
    $.ajax({
        url: '/api/get_shopping_cart_number/',
        dataType: "json",
        success: function(success) {
            // console.log(success);
            $(".cart-count-list").text(success.count ? success.count : "0")
            console.log("localstorage allow to show cart details => ",localStorageAllowAccess.getItem('set_location_based'))
            localStorageAllowAccess.getItem('set_location_based') == 'changed' && checkStateIdCame()
        },
        error: (error) => {
            console.log("error is =>", error);
        },
    });
};

function checkStateIdCame(){
    loopUntilStateIdCame()
}

function loopUntilStateIdCame() {
    var state_id = $(".change_location").attr("data-state-id")

    if (state_id === '') { //we want it to match
        setTimeout(function () {
            console.log("state id is miising for cart location change");
            loopUntilStateIdCame()
        },50);
        return;
    }

    state_id !== '' && console.log("state id is :- ",state_id);
    state_id !== '' && show_reconfigure_cart(state_id)
}

function show_reconfigure_cart(state_id) {
    $.ajax({
        url: '/api/reconfigure_cart/',
        type:'POST',
        data:{
            state_id:state_id
        },
        dataType: "json",
        success: function(success) {
            console.log(success);
            console.log("localstorage allow to show cart details => ",localStorageAllowAccess.getItem('set_location_based'))
            localStorageAllowAccess.setItem('set_location_based',"showed")
            console.log("localstorage block to show cart details => ",localStorageAllowAccess.getItem('set_location_based'))
            if(success?.error_list.length > 0){
                success.error_list.map((mapData,index )=> {
                    setTimeout(() => {
                        var myToast = Toastify({
                            text: mapData,
                            duration: 5000,
                            close:true,
                            style:{
                                background: 'red',
                                color: 'white',
                            }
                        })
                        myToast.showToast();
                    }, index*500);
                })
            }

            window.location.pathname == "/shop/checkout1/" && call_product_details()
            window.location.pathname == "/shop/cart/" && changeOnCartPage(success)
        },
        error: (error) => {
            console.log("error is =>", error);
        },
    });
};

function changeOnCheckoutPage(result){
    $('.check-out-item').html($html_prod);
    $('.cart-product-price').text(result.total_price)
    $('.cart-product-cgst').text(result.cgst)
    $('.cart-product-sgst').text(result.sgst)
    $('.cart-product-subtotal').text(result.total_price_with_taxes)
    $('.cart-product-discount').text(result.discount)
    $('.cart-product-wallet').text(result.wallet ? result.wallet : 0.00)
    $('.cart-product-total').text(result.net_price)
    $('input[name="total_amount"]').val(result.net_price);
    $('input[name="shopping_cart_id"]').val(result.shopping_cart_id);
    $('input[name="gift_op_name"]').val(result.user.name);
    $('.cart-gift-wrap').text(0);
}

function changeOnCartPage(result){
    console.log("changeOnCartPage get called")
    $('.cart-product-price').text(result.serialize.total_price)
    $('.cart-product-cgst').text(result.serialize.cgst)
    $('.cart-product-sgst').text(result.serialize.sgst)
    $('.cart-product-subtotal').text(result.serialize.total_price_with_taxes)
    $('.cart-product-discount').text(result.serialize.discount)
    $('.cart-product-total').text(result.serialize.net_price)
    result.serialize.items.length > 0 && result.serialize.items.map(mapData => {
        var createdIdIs = '#cartItemNumber_'+ mapData.cart_item_id + ' .cart__price'
        console.log("inside llopp",createdIdIs);
        $('#cartItemNumber_'+ mapData.cart_item_id + ' .cart__price').html('<i class="fas fa-rupee-sign"></i> '+ mapData.total_price_taxes)
    })
}

function callNotificationCount() {
    $.ajax({
        url: '/accounts/user_notification_count/',
        dataType: "json",
        success: success => $(".notification_count").text(success.count ? success.count : "0"),
        error: (error) => console.log("error is =>", error),
    });
};

$(document).on('click','.add-to-cart-js',function(){
    var product_id = $(this).attr('data-id');
    add_to_cart_js(product_id);
})

$(document).on('click','.add-special-to-cart-js',function(){
    var product_id = $(this).attr('data-id');
    var offer_id = $(this).attr('data-offer-id');
    add_special_to_cart_js(product_id,offer_id);
})

function add_special_to_cart_js(product_id,offer_id){
    if(product_id && offer_id){
        $.ajax({
            type: "POST",
            url: "/api/add_offer_item_to_cart/",
            data: {
                pid: product_id,
                offer_id: offer_id,
                state_id:$(".change_location").attr("data-state-id"),
            },
            dataType: "json",
            success: function (data) {
                if (data.status == true) {
                    // alert(data.msg);
                    if(data.hasOwnProperty('msg'))
                    data.hasOwnProperty('msg') && $(".successPopupBottom .msg").text(data.msg);
                    data.hasOwnProperty('message') && $(".successPopupBottom .msg").text(data.message);
                    $(".successPopupBottom").removeClass("hide")
                    setTimeout(() => {
                        $(".successPopupBottom").addClass("hide")
                    }, 4000);
                    callCartCount();
                } else {
                    data.hasOwnProperty('msg') && $(".errorPopupBottom .msg").text(data.msg);
                    data.hasOwnProperty('message') && $(".errorPopupBottom .msg").text(data.message);
                    data.hasOwnProperty('error') && $(".errorPopupBottom .msg").text(data.error);
                    $(".errorPopupBottom").removeClass("hide")
                    setTimeout(() => {
                        $(".errorPopupBottom").addClass("hide")
                    }, 4000);
                }
            }
        });
    }
}

async function getProductDetailByID(pid,sid){
    return await $.ajax({
        type: "GET",
        url: "/api/get_analytics_data/",
        data:{
            id:pid,
            state_id:sid,
        },
        dataType: "JSON",
        success: function (response) {
            return response
        },
        error: function (response) {
            console.log("api error get_analytics_data =>",response)
        },
    });
}

function addToCartAnalytics(response){
    console.log("response us",response);
    // console.log(" response.name => ",response.name," | response.price",response.price," | response.id",response.id)
    dataLayer.push({
        'event': 'addToCart',
        'ecommerce': {
            'currencyCode': 'INR',
            'add': {                                
                'products': [{
                    'name': response.name,
                    'id': response.id,
                    'price': response.price,
                    'quantity': 1
                }]
            }
        },
        'btnClass': 'add-2-cart'
    });
}

function add_to_cart_js(product_id){
    var sid = $(".change_location").attr("data-state-id")
    if(product_id){
        $.ajax({
            type: "POST",
            url: "/shop/add_item_to_cart/",
            data: {
                pid: product_id,
                state_id:sid,
            },
            dataType: "json",
            success: function (data) {
                if (data.status == true) {
                    // alert(data.msg);
                    if(data.hasOwnProperty('msg'))
                    data.hasOwnProperty('msg') && $(".successPopupBottom .msg").text(data.msg);
                    data.hasOwnProperty('message') && $(".successPopupBottom .msg").text(data.message);
                    $(".successPopupBottom").removeClass("hide")
                    setTimeout(() => {
                        $(".successPopupBottom").addClass("hide")
                    }, 4000);
                    callCartCount();
                    getProductDetailByID(product_id,sid).then(response => {
                        console.log("response is=>",response)
                        addToCartAnalytics(response)
                    });
                } else {
                    data.hasOwnProperty('msg') && $(".errorPopupBottom .msg").text(data.msg);
                    data.hasOwnProperty('message') && $(".errorPopupBottom .msg").text(data.message);
                    data.hasOwnProperty('error') && $(".errorPopupBottom .msg").text(data.error);
                    $(".errorPopupBottom").removeClass("hide")
                    setTimeout(() => {
                        $(".errorPopupBottom").addClass("hide")
                    }, 4000);
                }
            }
        });
    }
}

$(document).on('click','.buy-now-js',function(){
    var product_id = $(this).attr('data-id');
    if(product_id){
        $.ajax({
            type: "POST",
            url: "/shop/add_item_to_cart/",
            data: {
                pid: product_id,
                state_id:$(".change_location").attr("data-state-id"),
            },
            dataType: "json",
            success: function (data) {
                if (data.status == true) {
                    // alert(data.msg);
                    $(".successPopupBottom .msg").text(data.msg);
                    $(".successPopupBottom").removeClass("hide")
                    setTimeout(() => {
                        $(".successPopupBottom").addClass("hide")
                    }, 4000);
                    window.location.href = '/shop/checkout1/'
                } else {
                    $(".errorPopupBottom .msg").text(data.msg);
                    $(".errorPopupBottom").removeClass("hide")
                    $(".errorPopupBottom p").html(data.msg)
                    setTimeout(() => {
                        $(".errorPopupBottom").addClass("hide")
                    }, 4000);
                }
            }
        });
    }
})

$(document).on('click','.add-special-to-buy-js',function(){
    var product_id = $(this).attr('data-id');
    var offer_id = $(this).attr('data-offer-id');
    if(product_id){
        $.ajax({
            type: "POST",
            url: "/api/add_offer_item_to_cart/",
            data: {
                pid: product_id,
                offer_id:offer_id,
                state_id:$(".change_location").attr("data-state-id"),
            },
            dataType: "json",
            success: function (data) {
                if (data.status == true) {
                    // alert(data.msg);
                    $(".successPopupBottom .msg").text(data.msg);
                    $(".successPopupBottom").removeClass("hide")
                    setTimeout(() => {
                        $(".successPopupBottom").addClass("hide")
                    }, 4000);
                    window.location.href = '/shop/checkout1/'
                } else {
                    $(".errorPopupBottom .msg").text(data.msg);
                    $(".errorPopupBottom").removeClass("hide")
                    $(".errorPopupBottom p").html(data.msg)
                    setTimeout(() => {
                        $(".errorPopupBottom").addClass("hide")
                    }, 4000);
                }
            }
        });
    }
})

$(document).on('click','.wish-list-js',function(){
    // alert(id)
    // var id              = $(this).attr('id');
    var product_id      = $(this).attr('data-id');
    var wish_list_id    = $(this).attr('data-wish-list-id');
    $.ajax({
        type: "POST",
        url: "/api/add_wish/",
        data: { product_id: product_id },
        dataType: "json",
        success:function(result){
            // console.log(result);
            // console.log('product_id:'+product_id);
            if(result.status == true){
                if(result.code == 113){
                    $('#wishlist_'+product_id+' i').removeClass('fas fa-heart');
                    $('#wishlist_'+product_id+' i').addClass('icon-heart');

                    $(".successPopupBottom .msg").text(result.message);
                    $(".successPopupBottom").removeClass("hide")
                    setTimeout(() => {
                        $(".successPopupBottom").addClass("hide")
                    }, 4000);
                }
                if(result.code == 112){
                    $('#wishlist_'+product_id+' i').addClass('fas fa-heart');
                    $('#wishlist_'+product_id+' i').removeClass('icon-heart');

                    $(".successPopupBottom .msg").text(result.message);
                    $(".successPopupBottom").removeClass("hide")
                    setTimeout(() => {
                        $(".successPopupBottom").addClass("hide")
                    }, 4000);
                }
            } else {
                // alert(result.message);
                $(".errorPopupBottom .msg").text(result.message);
                $(".errorPopupBottom").removeClass("hide")
                setTimeout(() => {
                    $(".errorPopupBottom").addClass("hide")
                }, 4000);

                if(result.status == false && result.code == 111 && result.message == "Please login"){
                    $('#loginUserModal').modal('show');
                }
            }
            
        }
    })
})

$(document).on('change','.add-compare-js',function(e){
    e.preventDefault();
    // console.log('add-compare-js');
    var pid = $(this).attr('data-id');
    var compare_count = parseInt($('.compare-count').text());

    // console.log(pid);
    if($(this).prop('checked') == true){
        $.ajax({
            type: "POST",
            url: "/api/add_to_compare/",
            data: { pid: pid },
            dataType: "json",
            success:function(result){
                console.log("compare add_to_compare item",result);
                // console.log(result);
                // console.log('product_id:'+pid);
                if(result.status == true){
                    compare_count = compare_count + 1;
                    $('.compare-count').html(compare_count);
                    setTimeout(function() { $('.compare-item').show(); }, 300);
                    compare_item_details()
                    $(".successPopupBottom .msg").text(result.message);
                    $(".successPopupBottom").removeClass("hide")
                    setTimeout(() => {
                        $(".successPopupBottom").addClass("hide")
                    }, 4000);
                } else {
                    $(".errorPopupBottom .msg").text(result.message);
                    $(".errorPopupBottom").removeClass("hide")
                    setTimeout(() => {
                        $(".errorPopupBottom").addClass("hide")
                    }, 4000);
                }
            }
        })
    } else {
        $.ajax({
            type: "POST",
            url: "/api/remove_from_compare/",
            data: { pid: pid },
            dataType: "json",
            success:function(result){
                // console.log(result);
                // console.log('product_id:'+pid);
                if(result.status == true){
                    compare_count = compare_count - 1;
                    $('.compare-count').html(compare_count);
                    setTimeout(function() { $('.compare-item').show(); }, 300);
                    compare_item_details()
                    $(".successPopupBottom .msg").text(result.message);
                    $(".successPopupBottom").removeClass("hide")
                    setTimeout(() => {
                        $(".successPopupBottom").addClass("hide")
                    }, 4000);
                } else {
                    $(".errorPopupBottom .msg").text(result.message);
                    $(".errorPopupBottom").removeClass("hide")
                    setTimeout(() => {
                        $(".errorPopupBottom").addClass("hide")
                    }, 4000);
                }
            }
        })
    }
    
})


function compare_item_details(){
    $.ajax({
        type: "GET",
        url: "/api/compare/",
        dataType: "json",
        success:function(result){
            if(result){
                if(result.hasOwnProperty('items')){
                    if(result.items.length > 0){
                        var compare_html = '';
                        var j = 0;
                        $.each(result.items,function(i,value){
                            // Product Detail Page Make Checkbox true
                            if($('#compare_input_checkbox').length){
                                if($("#compare_input_checkbox").val() == value.id){
                                    $("#compare_input_checkbox").prop("checked",true)
                                }
                            }
                            // compare_category = value.product_serialize.category_id;
                            compare_html +=`<div class="compare-product-item" id="com_pro_${value.id}">
                                                <span class="close delete-compare" data-id="${value.id}">x</span>
                                                
                                                <a href="javascript:void(0);" class="compare-link">
                                                    <img src="${value.product_serialize.image != '' && value.product_serialize.image !== null ? value.product_serialize.image : '/static/assets/pai/images/placeholder-image.jpg'}" alt="${value.product_serialize.title}" />
                                                    <span class="compare-title">${value.product_serialize.title}</span>
                                                </a>
                                            </div>`;
                            j = j + 1;
                            // console.log(value.id);
                            compare_item.push(value.id);
                            // console.log('compare_'+value.id);
                            // console.log(compare_item);
                        });
                        // console.log('j:'+j);
                        $('.compare-count').text(j);
                        $('.compare-item .compare-product').html(compare_html);
                        
                        $('.compare-sticky').show();
                    } else {
                        $('.compare-sticky').hide();
                    } 
                } else {
                    $('.compare-sticky').hide();
                } 

            } else {
                $('.compare-sticky').hide();
            }
              
        }
    })
}


function wish_list_details(){
    $.ajax({
        type: "GET",
        url: "/api/wish_list_list/",
        dataType: "json",
        success:function(result){
            if(result.length > 0){
                $.each(result,function(i,value){
                    // console.log(value.id);
                    wished_item.push(value);
                    // console.log('wished_'+value);
                });
            } 
        }
    })
}


$(document).on('click','#setPincode',function(e){
    e.preventDefault();
    var form = $(this).closest('form');   
    // console.log(form);        
    form.validate({
        rules: {
            pincode: {
                required: true,
                number: true,
                minlength: 6,
                maxlength: 6
            }
        }
    });

    if (!form.valid()) {
        return;
    }
    $('#setPincode').attr('disabled',true); 
    var pincode = $('input[name="pincode"]').val();
    $.ajax({
        url         : '/api/get_localities_from_pin_code/?code='+pincode, //set_location_via_pincode ///?code:
        type        : 'POST',
        dataType    : 'JSON',
        success: function(response) {
            if(response){
                var saved_pincode = '';
                if(response.length > 0){
                    // $(form).hide();
                    $('input[name="pincode"]').attr('readonly',true);
                    saved_pincode +=`<span> Please choose nearest Locality </span>`;
                    saved_pincode +=`<ul>`;
                    $.each(response,function(i,v){
                        saved_pincode +=`<li>
                                            <a href="javascript:void(0);" class="set_location_based" data-pincode="${pincode}" data-locality="${v[0]}">
                                                <div class="address-details">
                                                    <strong>${v[0]} </strong>
                                                </div>
                                            </a>
                                            </li>`;
                    })
                    saved_pincode +=`</ul>`;
                }
                $('.reference_location').html(saved_pincode);
            }
            // $('.change_location').text(response.name);
            // $('.change_location').attr("data-state-id",response.state_id);
            // $('#location').modal('hide');
            // $('#setPincode').attr('disabled',false); 
            // console.log(response.status);
        },
        error:function(){
            $('#setPincode').attr('disabled',false);
            $('#setPincode').attr('disabled',true); 
            $('.reference_location').html('<span class="error"> Please try with some other pincode</span>');
        }
    })
})

$(document).on('click','.set_location_based',function(){
    var pincode = $(this).attr('data-pincode');
    var locality = $(this).attr('data-locality');
    $.ajax({
        url         : '/api/set_location_via_pincode/', //set_location_via_pincode //get_localities_from_pin_code/?code:
        type        : 'POST',
        dataType    : 'JSON',
        data        : {pincode:pincode,locality:locality},
        success: function(response) {
            // console.log(response)
            $('input[name="pincode"]').attr('readonly',false);
            $('.change_location').html(response.name.replace('\r\n',"<br/>"));
            $('.change_location').attr("data-state-id",response.state_id);
            $('#location').modal('hide');
            $('#setPincode').attr('disabled',false); 
            // console.log(response.status);
            localStorageAllowAccess.setItem("set_location_based","changed")

            // For Changing Location Based price in product listing page
            if(window.location.pathname.includes("/shop/categories")){
                var csrf_token = $("input#cat_product_listing_csrf").val()
                $.ajax({
                    type: "POST",
                    url: window.location.pathname,
                    data: {csrfmiddlewaretoken: csrf_token},
                    dataType: "json",
                    success: function (response) {
                        if(!window.location.pathname.includes("reduxed")){
                            window.location.href = window.location.pathname + "reduxed/"
                        }
                        else{
                            window.location.reload();
                        }
                    },
                    error: function (response) {
                        if(!window.location.pathname.includes("reduxed")){
                            window.location.href = window.location.pathname + "reduxed/"
                        }
                        else{
                            window.location.reload();
                        }
                    }
                });
            }else{
                window.location.reload()
            }
        },
        error : function(){
            set_defult_location();
            $('#location').modal('hide');
        }
    })
})



// $(document).on('hover',,function(){
//     $('.compare-product').show();
// })

// function addToCart(id) {
//     console.log(id);
//     $.ajax({
//         type: "POST",
//         url: "/shop/add_item_to_cart/",
//         data: {
//             pid: id,
//         },
//         dataType: "json",
//         success: function (data) {
//             if (data.status == true) {
//                 alert(data.msg);
//                 callCartCount()
//             } else {
//                 alert(data.msg);
//             }
//         }
//     });
// }


// $(document).on('click','.addtocart',function(){
//     var id = $(this).attr('data-id');
//     var pid = $(this).attr('data-product_id');
//     console.log(pid);
//     $.ajax({
//         type: "POST",
//         url: "/shop/add_item_to_cart/",
//         data: {
//             pid: id,
//         },
//         dataType: "json",
//         success: function (data) {
//             if (data.status == true) {
//                 alert(data.msg);
//                 callCartCount();
//             } else {
//                 alert(data.msg);
//             }
//         }
//     });
// })

var $window = $(window),
    $body = $("body"),
    $header = $("#header"),
    $mainMenu = $("#mainMenu"),
    $mainMenuTriggerBtn = $("#mainMenu-trigger a, #mainMenu-trigger button"),
    $scrollTop = $("#scrollTop");

if ($header.length > 0) {
    var $headerOffsetTop = $header.offset().top;
}

var Events = {
    browser: {
        isMobile: function() {
            if ( navigator.userAgent.match(/(iPhone|iPod|iPad|Android|BlackBerry)/)) {
                return true;
            } else {
                return false;
            }
        }
    }
};

//Settings
var Settings = {
    isMobile: Events.browser.isMobile,
    submenuLight: $header.hasClass("submenu-light") == true ? true : false,
    menuIsOpen: false,
    menuOverlayOpened: false
};

$(window).breakpoints({
    breakpoints: [
        {
            name: "xs",
            width: 0
        },
        {
            name: "sm",
            width: 576
        },
        {
            name: "md",
            width: 768
        },
        {
            name: "lg",
            width: 1025
        },
        {
            name: "xl",
            width: 1200
        }
    ]
});


var currentBreakpoint = $(window).breakpoints("getBreakpoint");
$body.addClass("breakpoint-" + currentBreakpoint);
$(window).bind("breakpoint-change", function(breakpoint) {
    $body.removeClass("breakpoint-" + breakpoint.from);
    $body.addClass("breakpoint-" + breakpoint.to);
});
$(window).breakpoints("greaterEqualTo", "lg", function() {
    $body.addClass("b--desktop");
    $body.removeClass("b--responsive");
});
$(window).breakpoints("lessThan", "lg", function() {
    $body.removeClass("b--desktop");
    $body.addClass("b--responsive");
});

if ($mainMenu.length > 0) {
    var $menuItemLinks = $("#mainMenu nav > ul > li.dropdown > a, .dropdown-submenu > a, .dropdown-submenu > span, .page-menu nav > ul > li.dropdown > a"),
    $triggerButton = $("#mainMenu-trigger a, #mainMenu-trigger button"),
    darkClassRemoved,
    processing = false,
    triggerEvent;
    $triggerButton.on("click", function(e) {
        var elem = $(this);
        e.preventDefault();
        $(window).breakpoints("lessThan", "lg", function() {
            var openMenu = function() {
                if (!processing) {
                    processing = true;
                    Settings.menuIsOpen = true;
                    if (Settings.submenuLight) {
                        $header.removeClass("dark");
                        darkClassRemoved = true;
                    }
                    elem.addClass("toggle-active");
                    $body.addClass("mainMenu-open");
                    $mainMenu.animate({
                        "min-height": $window.height()
                    },
                    {
                        duration: 500,
                        easing: "easeInOutQuart",
                        start: function() {
                            setTimeout(function() { $mainMenu.addClass("menu-animate"); }, 300);
                        },
                        complete: function() {
                            processing = false;
                        }
                    });
                }
            };

            var closeMenu = function() {
                if (!processing) {
                    processing = true;
                    Settings.menuIsOpen = false;
                    $mainMenu.animate( 
                        { "min-height": 0 },
                        { 
                            start: function() {
                                $mainMenu.removeClass("menu-animate");
                            },
                            done: function() {
                                $body.removeClass("mainMenu-open");
                                elem.removeClass("toggle-active");
                                if (Settings.submenuLight && darkClassRemoved) {
                                    $header.addClass("dark");
                                }
                            },
                            duration: 500,
                            easing: "easeInOutQuart",
                            complete: function() {
                                processing = false;
                            }
                        }
                    );
                }
            };

            if (!Settings.menuIsOpen) {
                triggerEvent = openMenu();
            } else {
                triggerEvent = closeMenu();
            }
        });
    });
    
    $(window).breakpoints("lessThan", "lg", function() { 
        $menuItemLinks.on("click", function(e) {
            $(this) .parent("li") .siblings() .removeClass("hover-active");
            $(this) .parent("li") .toggleClass("hover-active");
            e.stopPropagation();
            e.preventDefault();
        });
    });
    
    $menuItemLinks.on("click", function(e) {
        // $(this)
        //  .parent("li")
        //  .siblings()
        //  .removeClass("hover-active");
        // $(this)
        // .parent("li")
        // .toggleClass("hover-active");
        //e.stopPropagation();
        //e.preventDefault();
    });
    $body.on("click", function(e) {
        $mainMenu.find(".hover-active").removeClass("hover-active");
    });
    /*invert menu fix*/
    $(window).breakpoints("greaterEqualTo", "lg", function() {
        var $menuLastItem = $("nav > ul > li:last-child"),
        $menuLastItemUl = $("nav > ul > li:last-child > ul"),
        $menuLastInvert = $menuLastItemUl.width() - $menuLastItem.width(),
        $menuItems = $("nav > ul > li").find(".dropdown-menu");
        $menuItems.css("display", "block");
        $(".dropdown:not(.mega-menu-item) ul ul").each(function(
            index,
            element
        ) {
            if ($window.width() - ($(element).width() + $(element).offset().left) < 0) {
                $(element).addClass("menu-invert");
            }
        });
        if ($window.width() - ($menuLastItemUl.width() + $menuLastItem.offset().left) < 0) {
            $menuLastItemUl.addClass("menu-last");
        }
        $menuItems.css("display", "");
    });
}


$(window).scroll(function(){
    // console.log('hello');
    // console.log($(window).scrollTop());
    $(window).breakpoints("lessThan", "lg", function() {
    });

    $(window).breakpoints("greaterEqualTo", "lg", function() {
        // console.log(pathArray[0]);
        if ($(window).scrollTop() >= 200) {
            // $('#header').addClass('fixed-header');
            // $scrollTop.css({ bottom: "26px", opacity: 1, "z-index": 9999 });
            // $('header').addClass('fixed-header');
        } else {
            // $('#header').removeClass('fixed-header');
            // $('header').removeClass('fixed-header');
            // $scrollTop.css({ bottom: "16px", opacity: 0 });
        }
    });
});

if ($scrollTop.length > 0) {
    $scrollTop.off("click").on("click", function() {
        $("body,html").stop(true).animate({
            scrollTop: 0
        }, 1000, "easeInOutExpo");
        return false;
    });
}


$(document).on('click','.compare-product-item .delete-compare',function(){
    var pid = $(this).attr('data-id');
    $.ajax({
        type: "POST",
        url: "/api/remove_from_compare/",
        data: { pid: pid },
        dataType: "json",
        success:function(result){
            if(result.status == true){
                $('#compare_'+pid).prop('checked',false);
                setTimeout(function() { $('.compare-item').show(); }, 300);
                compare_item_details()
            }
        }
    })
})


function redirectFuncApi(){
    var getSearchParams = $("#searchAllPaiProductInput").val()
    $("#showAllPaiProductMain").removeClass('active')
    $("#showAllPaiProductMain ul").html('')

    getSearchParams != '' && getSearchParams.trim() != '' && $.ajax({
        url: "/shop/search/?q="+getSearchParams,
        dataType: "json",
        success:function(result){
            window.location.href = "/shop/search_product/?q="+getSearchParams
        }
    })
}

function GetURLParameter(sParam){
    var sPageURL = window.location.search.substring(1);
    var sURLVariables = sPageURL.split('&');
    for (var i = 0; i < sURLVariables.length; i++) 
    {
        var sParameterName = sURLVariables[i].split('=');
        if (sParameterName[0] == sParam) 
        {
            return sParameterName[1];
        }
    }
}

// Search Product /shop/search/?q=nokia
function searchAllProductByApi(){
    var keyUpVal = $('#searchAllPaiProductInput').val()
    var openSearchStatus = keyUpVal.trim().length > 0 && $('#searchAllPaiProductInput').attr("open-status") == 'true' && $("#searchAllPaiProductInput").is(":focus")
    
    openSearchStatus && $.ajax({
        url: "/shop/search_autosuggest/?q="+keyUpVal,
        dataType: "json",
        success:function(result){
            var autosuggestArray = []
            if(result.length > 0){
                autosuggestArray.push('<ul class="p-2 m-0">');
                result.map(suggestMap => autosuggestArray.push('<li><a href="javscript:void(0)" onclick="goToSearchPage('+ "'"+ suggestMap + "',event" +')">'+ suggestMap +'</a></li>'));
                autosuggestArray.push('</ul>');

                // Show Suggestion List
                $('#showAllPaiProductMain').addClass("active")
            
                if(autosuggestArray){
                    $("#showAllPaiProductMain").html(autosuggestArray.join(""))
                }
            }
        },
    })

    !openSearchStatus && $("#showAllPaiProductMain").removeClass("active")
}

$(document).on('submit','#searchAllPaiProductForm',function(event){
    event.preventDefault()
    redirectFuncApi();
})

// $(document).on('keyup','#searchAllPaiProductInput',function(event){
//     event.preventDefault()
//     $(this).val().trim().length > 0 ? $("#searchAllPaiProductInput").attr("open-status",true) : $("#searchAllPaiProductInput").attr("open-status",false)
//     setTimeout(searchAllProductByApi(), 200);
// })

function goToSearchPage(getSearchParams,event){
    event.preventDefault();
    window.location.href = "/shop/search_product/?q="+getSearchParams
}


$(document).ready(function () {
    // window.location.pathname.includes('/shop/details/') as or
    if ((window.location.pathname == '/') || window.location.pathname.includes('/shop/details/')) {
        // $(".recentlyViewdProducts").show();
        $.ajax({
            type: "GET",
            url: "/shop/recently_viewed_products/",
            dataType: "json",
            success: function (success) {
                console.log("recently viewd product success having data is ",success);
                if(success.products.length > 5 && success.status){
                    $(".recentlyViewdProducts").show();
                    recentlyViewdArray = []

                    success.products.map(obj => {

                        var litralViewd = `<div class="item">
                                                <div class="product">
                                                    <div class="product-list-cate">
                                                        <div class="product-image">
                                                            <a href="${obj.product.url}" title="${ obj.product.title }"><img src="${obj.product.pic ? obj.product.pic : '/static/assets/pai/images/placeholder-image.jpg'}" alt="${ obj.product.title }" /> </a>
                                                            ${obj?.product?.discount > 0 ? ('<span class="product-sale-off">'+obj.product.discount+"%</span>" ) : ''}
                                                            <span class="product-wishlist">
                                                                    <a href="javascript:void(0)" class="wish-list-js newWishlistDesign" data-id="${obj.product.id}" id="wishlist_${obj.product.id}"><i class="icon-heart"></i></a>
                                                            </span>
                                                        </div>
                                                        <div class="product-description">
                                                            <div class="product-title">
                                                                <h3><a href="${obj.product.url}" title="${obj.product.title}">${ obj.product.title }</a></h3>
                                                            </div>
                                                            <div class="product-price">
                                                                ${obj.product.current_price ? ('<ins class="not-strike">â‚¹'+obj.product.current_price+"</ins>" ) : ''}
                                                                ${obj.product.mrp ? ('<ins class="strike">â‚¹'+obj.product.mrp+"</ins>" ) : ''}
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
        
                                            </div>`

                        recentlyViewdArray.push(litralViewd)

                    })
                    
                    $(".recentlyViewdProducts .recently-viewed-carousel-item .owl-carousel.owl-theme").html(recentlyViewdArray.join(''));

                    $('.recently-viewed-carousel-item .owl-carousel').owlCarousel({
                        stagePadding: 0,
                        loop: false,
                        dots: false,
                        margin: 30,
                        nav: false,
                        autoplay: false,
                        autoplayHoverPause: false,
                        navContainer: '.case-study-carousel1 .custom-nav',
                        responsive: {
                            0: {
                                items: 1
                            },
                            576 : {
                                items: 2
                            },
                            767 : {
                                 items: 3
                            },
                            1000: {
                                items: 4
                            },
                            1300: {
                                items: 5
                            }
                        }
                    });

                    setTimeout(showWishListForRecentlyViewed, 1000);



                }


            },
            error: function (error) {
                console.log("recently viewd product error having data is ",error);
            },
        });
    }
});

function showWishListForRecentlyViewed(){
    console.log("showWishListForRecentlyViewed func called",wished_item);
    for (let index = 0; index < wished_item.length; index++) {
        $(".newWishlistDesign[data-id='"+wished_item[index]+"'] i").addClass("fas fa-heart")
        $(".newWishlistDesign[data-id='"+wished_item[index]+"'] i").removeClass("icon-heart")
   }
}






// Ajax Setup
function getCookie(name) {
    console.log("getCookie called with name is",name);
    var cookieValue = null;
    if (document.cookie && document.cookie != '') {
        var cookies = document.cookie.split(';');
        for (var i = 0; i < cookies.length; i++) {
            var cookie = jQuery.trim(cookies[i]);
            // Does this cookie string begin with the name we want?
            if (cookie.substring(0, name.length + 1) == (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

// Ajax Setup
function getCSRFCookie(name) {
    console.log("getCSRFCookie called with name is",name);
    var cookieValue = null;
    if (document.cookie && document.cookie != '') {
        var cookies = document.cookie.split(';');
        for (var i = 0; i < cookies.length; i++) {
            var cookie = jQuery.trim(cookies[i]);
            // Does this cookie string begin with the name we want?
            if (cookie.substring(0, name.length + 1) == (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

$.ajaxSetup({ 
    beforeSend: function(xhr, settings) {
        var cookieCSRF = getCookie('csrftoken')
        console.log("old CSRFToken cookie: " + cookieCSRF);
        if(cookieCSRF === null || cookieCSRF === undefined || cookieCSRF === '') {
            cookieCSRF = getCSRFCookie('csrftoken')
            console.log("new cookie: " + cookieCSRF);
        }

        (!(/^http:.*/.test(settings.url) || /^https:.*/.test(settings.url)) && !this.crossDomain) && (xhr.setRequestHeader("X-CSRFToken", getCookie('csrftoken')))
    } 
});


$(document).on("click",function(){
    setTimeout(() => {
        if($("#searchAllPaiProductInput").is(":focus")){
            $("#searchAllPaiProductInput").attr("open-status",true)
        }
        else if(!$("#searchAllPaiProductInput").is(":focus")){
            $("#searchAllPaiProductInput").attr("open-status",false)
            $("#showAllPaiProductMain").removeClass("active")
        }
        else{
            return
        }        
    }, 100);
})



