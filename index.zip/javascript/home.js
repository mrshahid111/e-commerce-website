$(document).ready(function(){
    run_carousel('#category-div .carousel');
    // run_carousel('.home_banner .carousel');
    call_grid_view('.trend-product .shop .grid-layout');
    //trending_product_carousel();
    //brand_logo_carousel();
    // run_carousel('.widget1 .carousel');
    // run_carousel('.widget2 .carousel');
    // run_carousel('.widget3 .carousel');
    // run_carousel('.widget4 .carousel');
    // run_carousel('.widget5 .carousel');
    // run_carousel('.widget6 .carousel');
    // run_carousel('.widget7 .carousel');
    // run_carousel('.widget8 .carousel');
    run_carousel('#brand-index-div .carousel');

    $('.main-banner .owl-carousel').owlCarousel({
        stagePadding: 0,
        loop: true,
        dots: true,
        margin: 0,
        nav: false,
        autoplay: true,
        autoplayTimeout: 2500,
        autoplayHoverPause: true,
        navText: [
            '<i class="fas fa-angle-left"></i>',
            '<i class="fas fa-angle-right"></i>'
        ],
        // navContainer: '.main-banner .custom-nav',
        responsive: {
            0: {
                items: 1
            }
        }
    });

    $('.single-image-carousel-1 .owl-carousel').owlCarousel({
        stagePadding: 0,
        loop: true,
        dots: true,
        margin: 0,
        nav: false,
        autoplay: true,
        autoplayHoverPause: true,
        navText: [
            '<i class="fa fa-angle-left" aria-hidden="true"></i>',
            '<i class="fa fa-angle-right" aria-hidden="true"></i>'
        ],
        // navContainer: '.single-image-carousel-1 .custom-nav',
        responsive: {
            0: {
                items: 1
            }
        }
    });

    $('.single-image-carousel-item-1 .owl-carousel').owlCarousel({
        stagePadding: 0,
        loop: true,
        dots: true,
        margin: 30,
        nav: false,
        autoplay: true,
        autoplayHoverPause: true,
        navText: [
            '<i class="fa fa-angle-left" aria-hidden="true"></i>',
            '<i class="fa fa-angle-right" aria-hidden="true"></i>'
        ],
        navContainer: '.case-study-carousel1 .custom-nav',
        responsive: {
            0: {
                items: 1
            },
            576 : {
                items: 2
            },
            767 : {
                 items: 3
            },
            1000: {
                items: 4
            }
        }
    });

    $('.single-image-carousel-2 .owl-carousel').owlCarousel({
        stagePadding: 0,
        loop: true,
        dots: true,
        margin: 0,
        nav: false,
        autoplay: true,
        autoplayTimeout: 1500,
        autoplayHoverPause: true,
        lazyLoad:true,
        navText: [
            '<i class="fa fa-angle-left" aria-hidden="true"></i>',
            '<i class="fa fa-angle-right" aria-hidden="true"></i>'
        ],
        // navContainer: '.single-image-carousel-1 .custom-nav',
        responsive: {
            0: {
                items: 1
            }
        }
    });

    $('.single-image-carousel-item-2 .owl-carousel').owlCarousel({
        stagePadding: 0,
        loop: true,
        dots: true,
        margin: 30,
        nav: false,
        autoplay: true,
        autoplayTimeout: 2500,
        autoplayHoverPause: true,
        lazyLoad:true,
        navText: [
            '<i class="fa fa-angle-left" aria-hidden="true"></i>',
            '<i class="fa fa-angle-right" aria-hidden="true"></i>'
        ],
        navContainer: '.case-study-carousel .custom-nav',
        responsive: {
            0: {
                items: 1
            },
            576 : {
                items: 2
            },
            767 : {
                 items: 4
            },
            1000: {
                items: 4
            }
        }
    });

    $('.single-image-carousel-3 .owl-carousel').owlCarousel({
        stagePadding: 0,
        loop: true,
        dots: true,
        margin: 0,
        nav: false,
        autoplay: true,
        autoplayTimeout: 1500,
        autoplayHoverPause: true,
        navText: [
            '<i class="fa fa-angle-left" aria-hidden="true"></i>',
            '<i class="fa fa-angle-right" aria-hidden="true"></i>'
        ],
        // navContainer: '.single-image-carousel-1 .custom-nav',
        responsive: {
            0: {
                items: 1
            }
        }
    });

    $('.single-image-carousel-item-3 .owl-carousel').owlCarousel({
        stagePadding: 0,
        loop: true,
        dots: true,
        margin: 30,
        nav: false,
        autoplay: true,
        autoplayTimeout: 2500,
        autoplayHoverPause: true,
        navText: [
            '<i class="fa fa-angle-left" aria-hidden="true"></i>',
            '<i class="fa fa-angle-right" aria-hidden="true"></i>'
        ],
        navContainer: '.case-study-carousel3 .custom-nav',
        responsive: {
            0: {
                items: 1
            },
            576 : {
                items: 2
            },
            767 : {
                 items: 4
            },
            1000: {
                items: 4
            }
        }
    });

    $('.single-image-carousel-4 .owl-carousel').owlCarousel({
        stagePadding: 0,
        loop: true,
        dots: true,
        margin: 0,
        nav: false,
        autoplay: true,
        autoplayTimeout: 500,
        autoplayHoverPause: true,
        navText: [
            '<i class="fa fa-angle-left" aria-hidden="true"></i>',
            '<i class="fa fa-angle-right" aria-hidden="true"></i>'
        ],
        // navContainer: '.single-image-carousel-1 .custom-nav',
        responsive: {
            0: {
                items: 1
            }
        }
    });

    $('.single-image-carousel-item-4 .owl-carousel').owlCarousel({
        stagePadding: 0,
        loop: true,
        dots: true,
        margin: 30,
        nav: false,
        autoplay: true,
        autoplayTimeout: 2500,
        autoplayHoverPause: true,
        navText: [
            '<i class="fa fa-angle-left" aria-hidden="true"></i>',
            '<i class="fa fa-angle-right" aria-hidden="true"></i>'
        ],
        navContainer: '.case-study-carousel4 .custom-nav',
        responsive: {
            0: {
                items: 1
            },
            576 : {
                items: 2
            },
            767 : {
                 items: 4
            },
            1000: {
                items: 4
            }
        }
    });

    $('.single-image-carousel-5 .owl-carousel').owlCarousel({
        stagePadding: 0,
        loop: true,
        dots: true,
        margin: 0,
        nav: false,
        autoplay: true,
        autoplayTimeout: 2000,
        autoplayHoverPause: true,
        navText: [
            '<i class="fa fa-angle-left" aria-hidden="true"></i>',
            '<i class="fa fa-angle-right" aria-hidden="true"></i>'
        ],
        // navContainer: '.single-image-carousel-1 .custom-nav',
        responsive: {
            0: {
                items: 1
            }
        }
    });

    $('.single-image-carousel-item-5 .owl-carousel').owlCarousel({
        stagePadding: 0,
        loop: true,
        dots: true,
        margin: 30,
        nav: false,
        autoplay: true,
        autoplayTimeout: 2500,
        autoplayHoverPause: true,
        navText: [
            '<i class="fa fa-angle-left" aria-hidden="true"></i>',
            '<i class="fa fa-angle-right" aria-hidden="true"></i>'
        ],
        navContainer: '.case-study-carousel5 .custom-nav',
        responsive: {
            0: {
                items: 1
            },
            576 : {
                items: 2
            },
            767 : {
                 items: 3
            },
            1000: {
                items: 4
            }
        }
    });
    // single-image-carousel-1

    const e = document.querySelectorAll(".makeImgLazy"),
    t = (e) => {
        const t = e.dataset.src,
            a = e.dataset.alt,
            o = e.dataset.title;
        ((e) =>
            new Promise((t, a) => {
            const o = new Image();
            (o.src = e), (o.onload = t), (o.onerror = a);
            }))(t).then(() => {
            (e.src = t), (e.alt = a), (e.title = o);
        });
        },
        a = new IntersectionObserver(
        (e, a) => {
            for (var o = 0; o < e.length; o++)
            e[o].intersectionRatio > 0 &&
                (a.unobserve(e[o].target), t(e[o].target));
        },
        { root: null, rootMargin: "50px 0px", threshold: 0.01 }
        );
    for (var o = 0; o < e.length; o++) a.observe(e[o]);
});


function call_grid_view($id){
    // console.log($id)
    $($id).each(function() {
        var elem = $(this);
        elem.options = {
            itemSelector: elem.attr("data-item") || "portfolio-item",
            layoutMode: elem.attr("data-layout") || "masonry",
            filter: elem.attr("data-default-filter") || "*",
            stagger: elem.attr("data-stagger") || 0,
            autoHeight: elem.data("auto-height") == false ? false : true,
            gridMargin: elem.attr("data-margin") || 20,
            gridMarginXs: elem.attr("data-margin-xs"),
            transitionDuration: elem.attr("data-transition") || "0.45s",
            isOriginLeft: true,
            lazyLoad: elem.attr("data-lazy-load") ? elem.attr("lazy-load") : false,
        };

        $(window).breakpoints("lessThan", "lg", function() {
            elem.options.gridMargin =
            elem.options.gridMarginXs || elem.options.gridMargin;
        });

        elem.css( "margin", "0 -" + elem.options.gridMargin + "px -" + elem.options.gridMargin + "px 0");
        elem .find("." + elem.options.itemSelector) .css( "padding", "0 " + elem.options.gridMargin + "px " + elem.options.gridMargin + "px 0" );
        if (elem.attr("data-default-filter")) {
            var elemDefaultFilter = elem.options.filter;
            elem.options.filter = "." + elem.options.filter;
        }
        elem.append('<div class="grid-loader"></div>');
        var $isotopelayout = $(elem).imagesLoaded(function() {
            // init Isotope after all images have loaded
            $isotopelayout.isotope({
                layoutMode: elem.options.layoutMode,
                transitionDuration: elem.options.transitionDuration,
                stagger: Number(elem.options.stagger),
                resize: true,
                itemSelector:"." + elem.options.itemSelector + ":not(.grid-loader)",
                isOriginLeft: elem.options.isOriginLeft,
                autoHeight: elem.options.autoHeight,
                lazyLoad: elem.options.lazyLoad,
                masonry: {
                    columnWidth: elem.find(
                        "." + elem.options.itemSelector + ":not(.large-width)"
                    )[0]
                },
                filter: elem.options.filter
            });
            elem.remove(".grid-loader").addClass("grid-loaded");
        });
    });
}

function customHeight(){
    var $customHeight = $(".custom-height");
    if ($customHeight.length > 0) {
        $customHeight.each(function() {
            var elem = $(this),
                elemHeight = elem.attr("data-height") || 400,
                elemHeightLg = elem.attr("data-height-lg") || elemHeight,
                elemHeightMd = elem.attr("data-height-md") || elemHeightLg,
                elemHeightSm = elem.attr("data-height-sm") || elemHeightMd,
                elemHeightXs = elem.attr("data-height-xs") || elemHeightSm;

            function customHeightBreakpoint(setHeight) {
                if (setHeight) {
                    elem = setHeight;
                }
                switch ($(window).breakpoints("getBreakpoint")) {
                    case "xs":
                        elem.height(elemHeightXs);
                        break;
                    case "sm":
                        elem.height(elemHeightSm);
                        break;
                    case "md":
                        elem.height(elemHeightMd);
                        break;
                    case "lg":
                        elem.height(elemHeightLg);
                        break;
                    case "xl":
                        elem.height(elemHeight);
                        break;
                }
            }
            customHeightBreakpoint(setHeight);
            $(window).resize(function() {
                setTimeout(function() {
                    customHeightBreakpoint(setHeight);
                }, 100);
            });
        });
    }
}

function run_carousel($id){
    var elem = $($id);
    //Plugin Options
    elem.options = {
        containerWidth: elem.width(),
        items: elem.attr("data-items") || 4,
        itemsLg: elem.attr("data-items-lg"),
        itemsMd: elem.attr("data-items-md"),
        itemsSm: elem.attr("data-items-sm"),
        itemsXs: elem.attr("data-items-xs"),
        margin: elem.attr("data-margin") || 10,
        cellSelector: elem.attr("data-item") || false,
        prevNextButtons: elem.data("arrows") == false ? false : true,
        pageDots: elem.data("dots") == false ? false : true,
        fade: elem.data("fade") == true ? true : false,
        draggable: elem.data("drag") == false ? false : true,
        freeScroll: elem.data("free-scroll") == true ? true : false,
        wrapAround: elem.data("loop") == false ? false : true,
        groupCells: elem.data("group-cells") == true ? true : false,
        autoPlay: elem.attr("data-autoplay") || 5000,
        pauseAutoPlayOnHover:
        elem.data("hover-pause") == false ? false : true,
        asNavFor: elem.attr("data-navigation") || false,
        lazyLoad: elem.data("lazy-load") ? elem.data("lazy-load") : false,
        initialIndex: elem.attr("data-initial-index") || 0,
        accessibility: elem.data("accessibility") == true ? true : false,
        adaptiveHeight: elem.data("adaptive-height") == true ? true : false,
        autoWidth: elem.data("auto-width") == true ? true : false,
        setGallerySize: elem.data("gallery-size") == false ? false : true,
        resize: elem.data("resize") == false ? false : true,
        cellAlign: elem.attr("data-align") || "left",
        rightToLeft: false,
        autoHeight: elem.data("auto-height") == true ? true : false,
    };
    //Calculate min/max on responsive breakpoints
    elem.options.itemsLg = elem.options.itemsLg || Math.min(Number(elem.options.items), Number(4));
    elem.options.itemsMd = elem.options.itemsMd || Math.min(Number(elem.options.itemsLg), Number(3));
    elem.options.itemsSm = elem.options.itemsSm || Math.min(Number(elem.options.itemsMd), Number(2));
    elem.options.itemsXs = elem.options.itemsXs || Math.min(Number(elem.options.itemsSm), Number(1));
    var setResponsiveColumns;

    function getCarouselColumns() {
        switch ($(window).breakpoints("getBreakpoint")) {
            case "xs":
                setResponsiveColumns = Number(elem.options.itemsXs);
                break;
            case "sm":
                setResponsiveColumns = Number(elem.options.itemsSm);
                break;
            case "md":
                setResponsiveColumns = Number(elem.options.itemsMd);
                break;
            case "lg":
                setResponsiveColumns = Number(elem.options.itemsLg);
                break;
            case "xl":
                setResponsiveColumns = Number(elem.options.items);
                break;
        }
    }
    getCarouselColumns();
    var itemWidth;
    elem.find("> *").wrap('<div class="polo-carousel-item">');
    if (elem.hasClass("custom-height")) {
        elem.options.setGallerySize = false;
        customHeight(elem);
        customHeight(elem.find(".polo-carousel-item"));
        var carouselCustomHeightStatus = true;
    }

    if (Number(elem.options.items) !== 1) {
        if (elem.options.autoWidth || carouselCustomHeightStatus) {
            elem.find(".polo-carousel-item").css({
                "padding-right": elem.options.margin + "px"
            });
        } else {
            itemWidth = (elem.options.containerWidth + Number(elem.options.margin)) / setResponsiveColumns;
            elem.find(".polo-carousel-item").css({
                width: itemWidth,
                "padding-right": elem.options.margin + "px"
            });
        }
    } else {
        elem.find(".polo-carousel-item").css({
            width: "100%",
            "padding-right": "0 !important;"
        });
    }

    if (elem.options.autoWidth || carouselCustomHeightStatus) {
        elem.options.cellAlign = "center";
    }

    if (elem.options.autoPlay == "false") {
        elem.options.autoPlay = false;
    }
    
    //Initializing plugin and passing the options
    var $carouselElem = $(elem);
    //   .imagesLoaded(function() {
    // init Isotope after all images have loaded
    console.log($id,"elem.options.autoHeight is=>",elem.options.autoHeight);
    console.log($id,"elem.options.lazyLoad is=>",elem.options.lazyLoad);

    $carouselElem.flickity({
        cellSelector: elem.options.cellSelector,
        prevNextButtons: elem.options.prevNextButtons,
        pageDots: elem.options.pageDots,
        fade: elem.options.fade,
        draggable: elem.options.draggable,
        freeScroll: elem.options.freeScroll,
        wrapAround: elem.options.wrapAround,
        groupCells: elem.options.groupCells,
        autoPlay: elem.options.autoPlay,
        pauseAutoPlayOnHover: elem.options.pauseAutoPlayOnHover,
        adaptiveHeight: elem.options.adaptiveHeight,
        asNavFor: elem.options.asNavFor,
        initialIndex: elem.options.initialIndex,
        accessibility: elem.options.accessibility,
        setGallerySize: elem.options.setGallerySize,
        resize: elem.options.resize,
        cellAlign: elem.options.cellAlign,
        rightToLeft: elem.options.rightToLeft,
        contain: true,
        imagesLoaded: true,
        autoHeight:elem.options.autoHeight,
        lazyLoad:elem.options.lazyLoad,
    });
    
    elem.addClass("carousel-loaded");

    if (elem.hasClass("custom-height")) {
        customHeight(elem);
    }

    if (Number(elem.options.items) !== 1) {
        $(window).on("resize", function() {
            setTimeout(function() {
                getCarouselColumns();
                itemWidth = (elem.width() + Number(elem.options.margin)) / setResponsiveColumns;
                if (elem.options.autoWidth || carouselCustomHeightStatus) {
                    elem.find(".polo-carousel-item").css({ "padding-right": elem.options.margin + "px"});
                } else {
                    if (!elem.hasClass("custom-height")) {
                        elem.find(".polo-carousel-item").css({
                            width: itemWidth,
                            "padding-right": elem.options.margin + "px"
                        });
                    } else {
                        customHeight(elem.find(".polo-carousel-item"));
                        elem.find(".polo-carousel-item").css({ 
                            width: itemWidth,
                            "padding-right": elem.options.margin + "px"
                        });
                    }
                }
                elem.find(".flickity-slider").css({
                    "margin-right": -elem.options.margin / setResponsiveColumns + "px"
                });
                elem.flickity("reposition");
            }, 100);
        });
    }

    $(document).ready(function () {
    $(".trend-product .shop .grid-layout img").bind('load',function() {
        call_grid_view('.trend-product .shop .grid-layout');
        });
    });
}
